export const coursesData = [
    "CA/ICWAI/M.COM/MBA Finance/B.com",
    "MBA Marketing",
    "MBA HR",
    "BTech/MTech/MCA/M.Sc Computers"];
export const itCourseData =[
    {
        "course":["Workday Finance","SAP FICO/S4 HANA Finance/BPC","Netsuite Finance","Oracle Finance"]

    },
    {
        "course":["Sales Force","SAP SD","SAP CRM"],
    },
    {
        "course":["WorkDay HCM","SAP Success Factors","People Soft"],
    },
    {
        "course":["Python","Cyber Security","Artificial Intelligence","Data Science","Block Chain","Muel Soft","Amazon Web Services(AWS)","Interent of things(IOT)","Machine Learning","Angular","Digital Marketing","IOS/Android Development","DevOps",".Net","Java"] 
    } 
];
export const trendyCourseData =[
    {
        "course":["Workday Finance","SAP FICO/S4 HANA Finance","Netsuite Finance","Oracle Finance"]
    },
    {
        "course":["Sales Force","SAP SD","SAP CRM"],
    },
    {
        "course":["WorkDay HCM","SAP Success Factors"],
    },
    {
        "course":["Python","Cyber Security","Artificial Intelligence","Data Science","RPA","Block Chain","Muel Soft","Amazon Web Services(AWS)","Interent of things(IOT)","Machine Learning","Angular","Digital Marketing","IOS/Android Development","Dev Apps","Java"]
    }
];